docker build -t demo05 .  
docker run -itd --name maggie -p 80:80 demo05
